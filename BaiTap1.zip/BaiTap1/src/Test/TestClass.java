package Test;

import java.util.Scanner;

import Class.PhanSo;

public class TestClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		PhanSo ps1_304=new PhanSo();
		PhanSo ps2_304=new PhanSo();
		PhanSo psTong =new PhanSo();
		
		// nhap phan so
		System.out.println("Nhap vao phan so thu nhat:");
		ps1_304.nhapPS(sc);
		System.out.println("Nhap vao phan so thu hai:");
		ps2_304.nhapPS(sc);
		
		// tinh tong 2 phan so
		psTong=ps1_304.congPS(ps2_304);
		
		// hien thi phan so
		System.out.println("\nPhan so thu nhat la:");
		ps1_304.hienThiPS();
		System.out.println("\nPhan so thu hai la:");
		ps2_304.hienThiPS();
		System.out.println("\nPhan so tong la:");
		psTong.hienThiPS();
		
		sc.close();
	}

}
