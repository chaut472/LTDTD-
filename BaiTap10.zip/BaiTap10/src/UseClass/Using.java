package UseClass;

import java.util.Scanner;

import BuildClass.QuanLy;

public class Using {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		QuanLy ql_304 = new QuanLy();
		ql_304.nhapDanhSach(sc);

		System.out.println("Danh sach bien lai cua cac ho gia dinh la:");
		ql_304.hienThiDanhSach();

		sc.close();
	}

}
