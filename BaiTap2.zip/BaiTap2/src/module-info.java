/**
 * 
 */
/**
 * 
 */
module BaiTap2 {
}