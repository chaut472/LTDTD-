package Class;

import java.util.Scanner;

public class CanBo {
	// thuoc tinh
	private String hoTen;
	private String ngaySinh;
	private String gioiTinh;
	private String diaChi;

	// phuong thuc
	// ham khoi tao khong doi so
	public CanBo() {

	}

	// ham khoi tao co doi so
	public CanBo(String hoten, String ngaySinh, String gioiTinh, String diaChi) {
		this.hoTen = hoten;
		this.ngaySinh = ngaySinh;
		this.gioiTinh = gioiTinh;
		this.diaChi = diaChi;
	}

	// ham nhap
	public void nhapThongTin(Scanner sc) {
		System.out.print("Nhap ho ten: ");
		hoTen = sc.nextLine();
		System.out.print("Nhap ngay sinh (dd/MM/yyyy): ");
		ngaySinh = sc.nextLine();
		System.out.print("Nhap gioi tinh: ");
		gioiTinh = sc.nextLine();
		System.out.print("Nhap dia chi: ");
		diaChi = sc.nextLine();
	}

	// ham hien thi
	public void hienThiThongTin() {
		System.out.println("Ho ten: " + hoTen);
		System.out.println("Ngay sinh: " + ngaySinh);
		System.out.println("Gioi tinh: " + gioiTinh);
		System.out.println("Dia chi: " + diaChi);
	}

	// ham lay thong tin ho ten
	public String getHoTen() {
		return this.hoTen;
	}
}
