package Class;

public class KhoiB extends KhoiA {
	// thuoc tinh

	// phuong thuc
	// ham khoi tao
	public KhoiB() {

	}

	public KhoiB(String mon1, String mon2, String mon3) {
		super(mon1, mon2, mon3);
	}
}
