package Class;

public class KhoiC extends KhoiA {
	// thuoc tinh

	// phuong thuc
	// ham khoi tao
	public KhoiC() {

	}

	public KhoiC(String mon1, String mon2, String mon3) {
		super(mon1, mon2, mon3);
	}
}
